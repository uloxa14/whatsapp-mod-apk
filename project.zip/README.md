# WAplug
Android-обёртка (WebView) над WhatsApp Web с мобильным интерфейсом и скриптом WAplug
(app/src/main/assets/waplug.js).

Сборка APK: залей папку в GitHub-репозиторий -> вкладка Actions -> "Build WAplug APK" ->
скачай артефакт WAplug-apk (debug APK, уже подписан отладочным ключом).

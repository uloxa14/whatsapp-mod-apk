(function () {
  if (window.__waplug) return;
  window.__waplug = true;
  const MODE = window.WAPLUG_MODE || 'qr';
  const NATIVE = window.AndroidWAplug;
  const CFG_KEY = 'waplug_cfg', DB_KEY = 'waplug_db';
  const def = { saveDeleted: true, showOld: true, theme: 'default', accent: '', bg: '', repl: [] };
  let cfg = Object.assign({}, def), db = {};
  try { cfg = Object.assign({}, def, JSON.parse(localStorage.getItem(CFG_KEY) || '{}')); } catch (e) {}
  try { db = JSON.parse(localStorage.getItem(DB_KEY) || '{}'); } catch (e) {}
  if (!Array.isArray(cfg.repl)) cfg.repl = [];
  const saveCfg = () => { try { localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch (e) {} };
  let dirty = false;
  const saveDb = () => {
    if (!dirty) return; dirty = false;
    const k = Object.keys(db);
    if (k.length > 5000) k.slice(0, 500).forEach(x => delete db[x]);
    try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch (e) {}
  };
  setInterval(saveDb, 5000);

  const TRASH = '<svg viewBox="0 0 24 24" width="16" height="16" fill="#e53935"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>';
  const PENCIL = '<svg viewBox="0 0 24 24" width="16" height="16" fill="#e53935"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>';

  const THEMES = {
    default: null,
    night:  { bg: '#0b1020', panel: '#121a33', out: '#1d3a8a', inn: '#1a2342', accent: '#5b8cff' },
    amoled: { bg: '#000000', panel: '#0a0a0a', out: '#0b5d4b', inn: '#161616', accent: '#00e0a4' },
    purple: { bg: '#1b1030', panel: '#25163f', out: '#6a2fb5', inn: '#2f1d52', accent: '#b57bff' },
    forest: { bg: '#0d1a12', panel: '#13261a', out: '#2d6a3e', inn: '#1a3324', accent: '#6fd08c' }
  };
  const THEME_NAMES = { default: 'Стандартная', night: 'Ночная', amoled: 'AMOLED', purple: 'Фиолетовая', forest: 'Лесная' };

  // ---------- styles ----------
  const style = document.createElement('style');
  document.documentElement.appendChild(style);
  const themeStyle = document.createElement('style');
  document.documentElement.appendChild(themeStyle);

  style.textContent = `
    html,body{overflow-x:hidden!important}
    body.wap-chat #side{display:none!important}
    body.wap-chat #main{width:100vw!important;max-width:100vw!important;flex:1 1 100%!important}
    body.wap-chat #main header{padding-left:52px!important}
    body:not(.wap-chat) #side{flex:1 1 100%!important;width:100%!important;max-width:100%!important}
    .wap-del{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;padding:6px 8px;font-size:14.2px}
    .wap-del .wap-dt{white-space:pre-wrap;word-break:break-word;opacity:.9}
    .wap-i{display:inline-flex;flex:none;float:right;margin-left:8px;margin-top:2px}
    .wap-del .wap-i{float:none}
    [data-wap-label]>*{display:none!important}
    [data-wap-label]::after{content:attr(data-wap-label);font-size:13px;font-weight:600;white-space:nowrap;color:#00a884}
    #waplug-root{font-family:system-ui,sans-serif}
    #wap-fab{position:fixed;right:0;top:45%;z-index:2147483646;background:#00a884;color:#fff;border-radius:12px 0 0 12px;padding:10px 8px;font-size:13px;font-weight:700;opacity:.65}
    #wap-back{position:fixed;left:6px;top:10px;z-index:2147483645;width:40px;height:40px;border-radius:20px;background:rgba(0,0,0,.45);color:#fff;font-size:22px;line-height:40px;text-align:center;display:none}
    body.wap-chat #wap-back{display:block}
    .wap-panel{position:fixed;inset:0;z-index:2147483647;background:#111b21;color:#e9edef;overflow-y:auto;padding:16px;display:none;-webkit-overflow-scrolling:touch}
    .wap-panel h2{margin:0 0 12px;color:#00a884}
    .wap-panel h3{margin:18px 0 8px;font-size:15px;color:#8696a0;text-transform:uppercase}
    .wap-row{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #222d34}
    .wap-panel input[type=text],.wap-panel select{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #2a3942;background:#202c33;color:#e9edef;font-size:15px}
    .wap-panel button{padding:12px 14px;border:0;border-radius:10px;background:#00a884;color:#fff;font-size:15px;margin:6px 6px 0 0}
    .wap-panel button.sec{background:#2a3942}
    .wap-panel button.red{background:#b3261e}
    .wap-pair{display:flex;gap:6px;margin-bottom:8px;align-items:center}
    .wap-pair button{margin:0;padding:10px 12px}
    .wap-panel small{color:#8696a0}
  `;

  function themeCss() {
    const t = THEMES[cfg.theme];
    const a = cfg.accent || (t && t.accent), bg = cfg.bg || (t && t.bg);
    if (!t && !a && !bg) return '';
    let v = '';
    if (bg) v += `--app-background:${bg};--app-background-deeper:${bg};--conversation-panel-background:${bg};--background-default:${bg};`;
    if (t) v += `--panel-header-background:${t.panel};--drawer-background:${t.panel};--incoming-background:${t.inn};--outgoing-background:${t.out};`;
    if (a) v += `--teal:${a};--primary:${a};--button-primary-background:${a};--unread-marker-background:${a};`;
    v = v.replace(/;/g, ' !important;');
    let extra = bg ? `body.waplug-theme #app,body.waplug-theme #app .two{background:${bg}!important}` : '';
    return `body.waplug-theme.waplug-theme{${v}}${extra}`;
  }
  function applyTheme() {
    themeStyle.textContent = themeCss();
    document.body && document.body.classList.toggle('waplug-theme', !!themeStyle.textContent);
  }

  // viewport for phone layout
  let vp = document.querySelector('meta[name=viewport]');
  if (!vp) { vp = document.createElement('meta'); vp.name = 'viewport'; document.head.appendChild(vp); }
  vp.content = 'width=device-width,initial-scale=1,maximum-scale=1';

  // ---------- messages ----------
  const IDRE = /^(true|false)_/;
  const DELRE = /(это сообщение удалено|вы удалили это сообщение|this message was deleted|you deleted this message)/i;
  const showNew = {};
  const getText = r => r.querySelector('span.selectable-text.copyable-text,span[data-testid="selectable-text"],span.selectable-text');

  function showDeleted(r, id) {
    if (r.querySelector('.wap-del')) return;
    const m = db[id];
    r.querySelectorAll('span').forEach(s => { if (!s.children.length && DELRE.test(s.textContent)) s.style.display = 'none'; });
    r.querySelectorAll('[data-icon="recalled"],[data-icon="status-recalled"]').forEach(i => i.style.display = 'none');
    const d = document.createElement('div');
    d.className = 'wap-del';
    d.innerHTML = '<span class="wap-dt"></span><span class="wap-i">' + TRASH + '</span>';
    d.firstChild.textContent = m.c;
    (r.querySelector('.message-in,.message-out') || r).appendChild(d);
  }

  function decorEdit(r, te, m) {
    let alt = r.querySelector('.wap-alt');
    if (m.o === m.c || !cfg.showOld) {
      if (alt) { alt.remove(); te.style.display = ''; }
      delete r.dataset.wapEdited; return;
    }
    r.dataset.wapEdited = '1';
    const id = r.getAttribute('data-id');
    if (!alt) {
      alt = document.createElement('span');
      alt.className = 'wap-alt';
      alt.innerHTML = '<span class="wap-t"></span><span class="wap-i">' + PENCIL + '</span>';
      te.parentNode.insertBefore(alt, te.nextSibling);
    }
    const t = alt.firstChild;
    const want = showNew[id] ? '' : m.o;
    const disp = showNew[id] ? '' : 'none';
    if (t.textContent !== want) t.textContent = want;
    if (te.style.display !== disp) te.style.display = disp;
  }

  function processMessages() {
    document.querySelectorAll('[data-id]').forEach(r => {
      const id = r.getAttribute('data-id');
      if (!IDRE.test(id)) return;
      const te = getText(r);
      const deleted = !te && (r.querySelector('[data-icon="recalled"],[data-icon="status-recalled"]') || DELRE.test(r.textContent));
      if (deleted) { if (cfg.saveDeleted && db[id]) showDeleted(r, id); return; }
      if (!te) return;
      const cur = te.textContent.trim();
      if (!cur) return;
      const m = db[id];
      if (!m) { db[id] = { o: cur, c: cur }; dirty = true; }
      else if (m.c !== cur) { m.c = cur; dirty = true; }
      decorEdit(r, te, db[id]);
    });
  }

  // triple tap on edited message
  let taps = [];
  document.addEventListener('click', e => {
    const r = e.target.closest && e.target.closest('[data-id]');
    if (!r || !IDRE.test(r.getAttribute('data-id')) || !r.dataset.wapEdited) return;
    const now = Date.now();
    taps = taps.filter(x => now - x.t < 700 && x.r === r);
    taps.push({ t: now, r });
    if (taps.length >= 3) {
      taps = [];
      const id = r.getAttribute('data-id');
      showNew[id] = !showNew[id];
      schedule(0);
    }
  }, true);

  // ---------- text replacement ----------
  function applyRepl() {
    const pairs = cfg.repl.filter(p => p.from && !(p.to || '').includes(p.from));
    if (!pairs.length) return;
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: n => {
        const p = n.parentElement;
        if (!p || p.closest('[data-id],#waplug-root,[contenteditable],script,style')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = []; let n; while ((n = w.nextNode())) nodes.push(n);
    nodes.forEach(n => {
      let v = n.nodeValue; const o = v;
      pairs.forEach(p => { if (v.includes(p.from)) v = v.split(p.from).join(p.to || ''); });
      if (v !== o) n.nodeValue = v;
    });
    document.querySelectorAll('[aria-label],[title],[placeholder]').forEach(el => {
      if (el.closest('#waplug-root,[data-id]')) return;
      pairs.forEach(p => {
        const f = p.from.toLowerCase();
        const al = el.getAttribute('aria-label');
        if (al && al.trim().toLowerCase() === f && el.matches('button,[role=button]')) {
          el.setAttribute('data-wap-label', p.to || '');
          el.setAttribute('aria-label', p.to || '');
        }
        ['title', 'placeholder'].forEach(a => {
          const v = el.getAttribute(a);
          if (v && v.includes(p.from)) el.setAttribute(a, v.split(p.from).join(p.to || ''));
        });
      });
    });
  }

  // ---------- phone-number login ----------
  let phoneTimer = null;
  if (MODE === 'phone') {
    phoneTimer = setInterval(() => {
      if (document.querySelector('#pane-side')) { clearInterval(phoneTimer); return; }
      const el = [...document.querySelectorAll('a,button,[role=button],span,div')].find(e =>
        e.children.length < 3 && e.textContent.length < 60 &&
        /link with phone number|phone number|по номеру телефона|номер телефона/i.test(e.textContent));
      if (el) { (el.closest('[role=button],a,button') || el).click(); clearInterval(phoneTimer); }
    }, 1000);
    setTimeout(() => clearInterval(phoneTimer), 90000);
  }

  // ---------- main loop ----------
  let loggedSent = false, timer = null, obs = null;
  function run() {
    if (obs) obs.disconnect();
    try {
      document.body.classList.toggle('wap-chat', !!document.querySelector('#main'));
      applyTheme();
      processMessages();
      applyRepl();
      if (!loggedSent && document.querySelector('#pane-side')) {
        loggedSent = true; NATIVE && NATIVE.setLoggedIn(true);
      }
    } catch (e) { console.log('WAplug', e); }
    if (obs) obs.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  function schedule(ms) {
    clearTimeout(timer);
    timer = setTimeout(run, ms == null ? 300 : ms);
  }

  // ---------- UI ----------
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function buildUI() {
    const root = document.createElement('div');
    root.id = 'waplug-root';
    root.innerHTML = '<div id="wap-fab">⚙ WAplug</div><div id="wap-back">←</div><div class="wap-panel"></div>';
    document.body.appendChild(root);
    const panel = root.querySelector('.wap-panel');
    root.querySelector('#wap-fab').onclick = () => { render(); panel.style.display = 'block'; };
    root.querySelector('#wap-back').onclick = () => {
      ['keydown', 'keyup'].forEach(t => document.dispatchEvent(new KeyboardEvent(t, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })));
    };

    function render() {
      panel.innerHTML = `
        <h2>WAplug <span id="wap-x" style="float:right;cursor:pointer">✕</span></h2>
        <div class="wap-row"><span>Save deleted messages<br><small>Удалённые сообщения остаются, справа красная мусорка</small></span><input type="checkbox" id="wap-del" ${cfg.saveDeleted ? 'checked' : ''}></div>
        <div class="wap-row"><span>Show old text from edited messages<br><small>Красный карандаш. Тройной тап — переключить старый/новый текст</small></span><input type="checkbox" id="wap-old" ${cfg.showOld ? 'checked' : ''}></div>
        <h3>Темы</h3>
        <select id="wap-theme">${Object.keys(THEMES).map(k => `<option value="${k}" ${cfg.theme === k ? 'selected' : ''}>${THEME_NAMES[k]}</option>`).join('')}</select>
        <div class="wap-row"><span>Акцентный цвет</span><input type="color" id="wap-acc" value="${cfg.accent || '#00a884'}"></div>
        <div class="wap-row"><span>Цвет фона</span><input type="color" id="wap-bg" value="${cfg.bg || '#111b21'}"></div>
        <button class="sec" id="wap-resettheme">Сбросить цвета</button>
        <h3>Тексты и кнопки</h3>
        <small>Впишите надпись точно как в интерфейсе (например «Отправить» или «Send») и на что заменить.</small>
        <div id="wap-pairs" style="margin-top:8px"></div>
        <button class="sec" id="wap-add">+ Добавить замену</button>
        <h3>Прочее</h3>
        <button id="wap-save">Сохранить и перезагрузить</button>
        <button class="sec" id="wap-login">Сменить способ входа</button>
        <button class="red" id="wap-clear">Очистить сохранённые сообщения</button>`;
      const pairs = panel.querySelector('#wap-pairs');
      const drawPairs = () => {
        pairs.innerHTML = cfg.repl.map((p, i) => `<div class="wap-pair"><input type="text" data-i="${i}" data-k="from" placeholder="Было" value="${esc(p.from)}"><input type="text" data-i="${i}" data-k="to" placeholder="Стало" value="${esc(p.to)}"><button class="red" data-rm="${i}">✕</button></div>`).join('');
      };
      drawPairs();
      pairs.oninput = e => { const t = e.target; if (t.dataset.k) cfg.repl[+t.dataset.i][t.dataset.k] = t.value; };
      pairs.onclick = e => { if (e.target.dataset.rm != null) { cfg.repl.splice(+e.target.dataset.rm, 1); drawPairs(); } };
      const $ = s => panel.querySelector(s);
      $('#wap-x').onclick = () => { panel.style.display = 'none'; };
      $('#wap-del').onchange = e => { cfg.saveDeleted = e.target.checked; saveCfg(); };
      $('#wap-old').onchange = e => { cfg.showOld = e.target.checked; saveCfg(); schedule(0); };
      $('#wap-theme').onchange = e => { cfg.theme = e.target.value; cfg.accent = ''; cfg.bg = ''; saveCfg(); applyTheme(); };
      $('#wap-acc').oninput = e => { cfg.accent = e.target.value; saveCfg(); applyTheme(); };
      $('#wap-bg').oninput = e => { cfg.bg = e.target.value; saveCfg(); applyTheme(); };
      $('#wap-resettheme').onclick = () => { cfg.theme = 'default'; cfg.accent = ''; cfg.bg = ''; saveCfg(); applyTheme(); render(); };
      $('#wap-add').onclick = () => { cfg.repl.push({ from: '', to: '' }); drawPairs(); };
      $('#wap-save').onclick = () => { cfg.repl = cfg.repl.filter(p => p.from); saveCfg(); saveDb(); location.reload(); };
      $('#wap-login').onclick = () => { if (NATIVE) NATIVE.resetLogin(); };
      $('#wap-clear').onclick = () => { if (confirm('Удалить все сохранённые сообщения?')) { db = {}; dirty = false; try { localStorage.removeItem(DB_KEY); } catch (e) {} } };
    }
  }

  function start() {
    if (!document.body) return setTimeout(start, 200);
    buildUI();
    obs = new MutationObserver(() => schedule());
    obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    run();
  }
  start();
})();

package com.waplug.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var mode: String
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    inner class Bridge {
        @JavascriptInterface
        fun setLoggedIn(v: Boolean) {
            getSharedPreferences("waplug", MODE_PRIVATE).edit().putBoolean("logged_in", v).apply()
        }
        @JavascriptInterface
        fun resetLogin() {
            getSharedPreferences("waplug", MODE_PRIVATE).edit().putBoolean("logged_in", false).apply()
            runOnUiThread {
                startActivity(Intent(this@MainActivity, ChooserActivity::class.java))
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "qr"
        web = WebView(this)
        setContentView(web)
        WebView.setWebContentsDebuggingEnabled(true)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            userAgentString = ua
            useWideViewPort = false
            loadWithOverviewMode = false
            setSupportZoom(false)
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }
        web.addJavascriptInterface(Bridge(), "AndroidWAplug")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val h = r.url.host ?: return false
                if (h.endsWith("whatsapp.com") || h.endsWith("whatsapp.net")) return false
                startActivity(Intent(Intent.ACTION_VIEW, r.url))
                return true
            }
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) = inject(v, url)
            override fun onPageFinished(v: WebView, url: String) = inject(v, url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p.createIntent(), 1); true
                } catch (e: Exception) {
                    fileCb = null; false
                }
            }
        }
        web.loadUrl("https://web.whatsapp.com/")
    }

    private fun inject(v: WebView, url: String) {
        if (!url.contains("whatsapp.com")) return
        val js = assets.open("waplug.js").bufferedReader().use { it.readText() }
        v.evaluateJavascript("window.WAPLUG_MODE=${JSONObject.quote(mode)};\n$js", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(req, res, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else @Suppress("DEPRECATION") super.onBackPressed()
    }
}

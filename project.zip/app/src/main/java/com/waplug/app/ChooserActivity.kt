package com.waplug.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ChooserActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("waplug", MODE_PRIVATE)
        if (p.getBoolean("logged_in", false)) {
            open(p.getString("mode", "qr") ?: "qr")
            return
        }
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(px(24), px(24), px(24), px(24))
            setBackgroundColor(Color.parseColor("#111B21"))
        }
        fun text(t: String, size: Float, color: String, bottom: Int) = TextView(this).apply {
            this.text = t; textSize = size; setTextColor(Color.parseColor(color))
            gravity = Gravity.CENTER; setPadding(0, 0, 0, px(bottom))
        }
        fun btn(t: String, mode: String) = Button(this).apply {
            this.text = t; isAllCaps = false; textSize = 16f
            setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#00A884"))
            setPadding(px(16), px(16), px(16), px(16))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(8) }
            setOnClickListener { p.edit().putString("mode", mode).apply(); open(mode) }
        }

        root.addView(text("WAplug", 30f, "#00A884", 8))
        root.addView(text("Как войти в WhatsApp?", 18f, "#E9EDEF", 24))
        root.addView(btn("Войти как дополнительное устройство (QR-код)", "qr"))
        root.addView(text(
            "QR-код нужно отсканировать другим телефоном: WhatsApp → Связанные устройства → Привязка устройства.",
            12f, "#8696A0", 20))
        root.addView(btn("Войти по номеру телефона", "phone"))
        root.addView(text(
            "Вы получите код, который нужно ввести в WhatsApp на телефоне: Связанные устройства → Привязка по номеру телефона.",
            12f, "#8696A0", 0))
        setContentView(root)
    }

    private fun open(mode: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra("mode", mode))
        finish()
    }
}
